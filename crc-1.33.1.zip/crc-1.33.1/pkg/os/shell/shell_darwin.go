package shell

var (
	supportedShell = []string{"bash", "zsh", "fish"}
)
