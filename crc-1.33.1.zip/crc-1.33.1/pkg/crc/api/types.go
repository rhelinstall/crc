package api

type loggerResult struct {
	Success  bool
	Messages []string
}
