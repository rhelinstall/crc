package machine

import (
	"github.com/code-ready/crc/pkg/crc/constants"
	"github.com/code-ready/crc/pkg/crc/logging"
	"github.com/code-ready/crc/pkg/crc/machine/state"
	crcssh "github.com/code-ready/crc/pkg/crc/ssh"
	"github.com/code-ready/crc/pkg/crc/systemd"
	"github.com/code-ready/crc/pkg/libmachine/host"
	"github.com/pkg/errors"
)

func (client *client) Stop() (state.State, error) {
	libMachineAPIClient, cleanup := createLibMachineClient()
	defer cleanup()
	host, err := libMachineAPIClient.Load(client.name)

	if err != nil {
		return state.Error, errors.Wrap(err, "Cannot load machine")
	}
	if err := stopAllContainers(host, client); err != nil {
		return state.Error, err
	}
	logging.Info("Stopping the OpenShift cluster, this may take a few minutes...")
	if err := host.Stop(); err != nil {
		status, stateErr := host.Driver.GetState()
		if stateErr != nil {
			logging.Debugf("Cannot get VM status after stopping it: %v", stateErr)
		}
		return state.FromMachine(status), errors.Wrap(err, "Cannot stop machine")
	}
	status, err := host.Driver.GetState()
	if err != nil {
		return state.Error, errors.Wrap(err, "Cannot get VM status")
	}
	return state.FromMachine(status), nil
}

// This should be removed after https://bugzilla.redhat.com/show_bug.cgi?id=1965992
// is fixed. We should also ignore the openshift specific errors because stop
// operation shouldn't depend on the openshift side. Without this graceful shutdown
// takes around 6-7 mins.
func stopAllContainers(host *host.Host, client *client) error {
	logging.Info("Stopping kubelet and all containers...")
	instanceIP, err := getIP(host, client.useVSock())
	if err != nil {
		return errors.Wrapf(err, "Error getting the IP")
	}
	sshRunner, err := crcssh.CreateRunner(instanceIP, getSSHPort(client.useVSock()), constants.GetPrivateKeyPath(), constants.GetRsaPrivateKeyPath())
	if err != nil {
		return errors.Wrapf(err, "Error creating the ssh client")
	}
	defer sshRunner.Close()

	if err := systemd.NewInstanceSystemdCommander(sshRunner).Stop("kubelet"); err != nil {
		return err
	}
	_, stderr, err := sshRunner.RunPrivileged("stopping all containers", `-- sh -c 'crictl stop $(crictl ps -q)'`)
	if err != nil {
		logging.Errorf("Failed to stop all containers: %v - %s", err, stderr)
		return err
	}
	return nil
}
