package hyperv

const (
	// Alternative
	AlternativeNetwork = "crc"
)
