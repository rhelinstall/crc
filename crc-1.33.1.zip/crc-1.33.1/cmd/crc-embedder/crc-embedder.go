package main

import (
	"github.com/code-ready/crc/cmd/crc-embedder/cmd"
)

func main() {
	cmd.Execute()
}
