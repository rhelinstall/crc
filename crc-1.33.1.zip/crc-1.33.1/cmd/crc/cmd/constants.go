package cmd

const (
	commandName      = "crc"
	descriptionShort = "Local OpenShift 4.x cluster"
	descriptionLong  = "CodeReady Containers is a tool that manages a local OpenShift 4.x cluster optimized for testing and development purposes"
)
