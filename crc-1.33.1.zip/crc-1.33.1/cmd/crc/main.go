package main

import (
	"github.com/code-ready/crc/cmd/crc/cmd"
)

func main() {
	cmd.Execute()
}
